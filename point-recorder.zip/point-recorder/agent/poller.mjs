// Compat: mantemos o nome "poller", mas ele só roda o worker (loop interno).
import './worker.mjs';

